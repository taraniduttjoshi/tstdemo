<?php 
include("includes/header.php");
?>

<div class="main_column column" id="main_column">
	<h4>User Closed</h4>

	This account is closed.
	<a href="index.php"> Click here to go back.</a>

</div>